INSTUCIONS

Play With Yourself/Friend
One Person press 1
Other press 2

Have Fun :)

Why This Was Created?

Because It was easy and a test of latency between both pages

Was Test Successfull?

YES!