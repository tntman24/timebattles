To: Whoever Installed This
From: tntman24
Subject: READ ME
Meassage:
Hello There! So, in this folder are Tests/Betas that were used in Time Battles Early Stages, I wanted to keep them in the files so incase I lose the files, I can re-install it. Anyways, might not work for you (Sadly) anyways, have a great day!

-tntman24