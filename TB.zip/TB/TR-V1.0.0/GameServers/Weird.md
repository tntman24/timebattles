This is... weird. Anyways, this version was supposed to have the entire thing in it, but had to be created in baby steps to get it to work. So... yea, have fun?

Regarding That Right Above This, the only thing is going to be the global stuff, so have fun!